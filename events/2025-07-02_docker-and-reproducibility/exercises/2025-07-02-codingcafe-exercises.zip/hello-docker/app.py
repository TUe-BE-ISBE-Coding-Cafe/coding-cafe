print("Hello from inside a Docker container!")
